<?php
/**
 * Created by PhpStorm.
 * User: Dungdt
 * Date: 4/21/2016
 * Time: 4:28 PM
 */
?>

<ol>
	<li>[order_id] : <?php _e('Order ID','wpbooking') ?></li>
	<li>[name_customer] : <?php _e('Name Customer','wpbooking') ?></li>
	<li>[order_status] : <?php _e('Order Status','wpbooking') ?></li>
	<li>[order_total] : <?php _e('Order Total','wpbooking') ?></li>
	<li>[order_payment_gateway] : <?php _e('Order Payment Gateway','wpbooking') ?></li>
	<li>[order_table] : <?php _e('Order Table','wpbooking') ?></li>
	<li>[checkout_info]: <?php _e('Checkout Form Information','wpbooking') ?> </li>
</ol>