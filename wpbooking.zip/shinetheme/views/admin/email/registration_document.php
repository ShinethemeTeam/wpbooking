<?php
/**
 * Created by PhpStorm.
 * User: Dungdt
 * Date: 6/27/2016
 * Time: 8:37 AM
 */
?>
<ol>
	<li>[user_login] : <?php esc_html_e('Username','wpbooking') ?></li>
	<li>[user_email]: <?php _e('User Email','wpbooking') ?> </li>
	<li>[user_pass]: <?php _e('User Password (Random Default Password, User should change it after logging in)','wpbooking') ?> </li>
	<li>[profile_url]: <?php _e('URL to My Account Page','wpbooking') ?> </li>
	<li>[edit_user_url]: <?php _e('[For Admin] URL to Edit User Page','wpbooking') ?> </li>
</ol>