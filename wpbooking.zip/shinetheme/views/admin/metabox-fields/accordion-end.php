<?php
/**
 * Created by PhpStorm.
 * User: Dungdt
 * Date: 6/21/2016
 * Time: 10:50 AM
 */
?>
<div class="clear"></div>
</div><!--End .wpbooking-metabox-accordion-content-->
</div><!--End .wpbooking-metabox-accordion-->

