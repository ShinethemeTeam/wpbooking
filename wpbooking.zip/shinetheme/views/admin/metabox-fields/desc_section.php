<div class="desc_section_metabox">
    <span class=""><i class="fa fa-thumb-tack"></i></span>
    <span class="title"><?php echo esc_html($data['title']) ?></span>
    <span class="content"><?php echo esc_html($data['content']) ?></span>
    <div class="border_section_metabox"></div>
</div>