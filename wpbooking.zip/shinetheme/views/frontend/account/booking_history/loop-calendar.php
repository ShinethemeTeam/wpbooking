<?php
/**
 * Created by PhpStorm.
 * User: Dungdt
 * Date: 6/14/2016
 * Time: 8:46 AM
 */
?>
<div id="wpbooking_order_calendar" class="clear">
	<div class="calendar-wrap"></div>
	<div class="clear"></div>
</div>
